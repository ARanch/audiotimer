from setuptools import setup, find_packages

setup(
    name='audiotimer',
    version='0.1',
    packages=find_packages(),
    # Add more parameters as needed
)
